from django.shortcuts import render
from django.core.exceptions import ObjectDoesNotExist
from .models import Operator,Alerts, Camera,Challans,NewAlerts, RejectedAlerts, Userload
from django.contrib.sessions.models import Session
from django import db
import os

def home(request):
    if request.session.has_key('operator'):
        query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
        freeCamsObj = Camera.objects.raw(query)

        if request.session.has_key('camid'):
            camid=request.session['camid']

            query = 'select new_alerts.alert_id, alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where camera_id=' + camid + ' and alerts.alert_id=new_alerts.alert_id'
            alertsobj = Alerts.objects.raw(query)

            context = {
                'alertsobj': alertsobj,
                'camid': camid,
                'freeCamsObj': freeCamsObj,
            }
            return render(request, 'htp/home.html', context)

        return render(request, 'htp/home.html', {'freeCamsObj':freeCamsObj})
    else:
        if request.session.has_key('admin'):
            return render(request, 'htp/htpadmin.html')
        else:
            return render(request, 'htp/login.html', {'error_message':'Please log in.'})


def userlogin(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        try:
            user = Operator.objects.get(op_credentials=username, op_password=password)
        except Operator.DoesNotExist:
            user = None

        if user is not None:
            if (user.op_details == "admin"):
                request.session['admin'] = user.op_id
                query = "select * from camera;"
                allCamsObj = Camera.objects.raw(query)

                return render(request, 'htp/htpadmin.html', {'allCamsObj': allCamsObj})
            else:
                #try:
                 #   operator = Userload.objects.get(op=user.op_id)
                #except Userload.DoesNotExist:
                 #   operator = None
                try:
                    operator = request.session['operator']
                except:
                    operator = None

                if ('operator' not in request.session) or ('operator' in request.session and request.session['operator']!=user.op_id):
                    request.session['operator'] = user.op_id
                    query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
                    freeCamsObj = Camera.objects.raw(query)
                    context = {
                        'freeCamsObj': freeCamsObj,
                        'operator': operator,
                        'u':user.op_id,
                    }
                    return render(request, 'htp/home.html', context)
                return render(request, 'htp/login.html', {'error_message': 'Please Login using different account. This user account is already in use.','operator':operator})
        else:
            return render(request, 'htp/login.html', {'error_message': 'Invalid Login'})

    else:
        if request.session.has_key('operator'):
            query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
            freeCamsObj = Camera.objects.raw(query)
            return render(request, 'htp/home.html', {'freeCamsObj': freeCamsObj})
        else:
            if request.session.has_key('admin'):
                return render(request, 'htp/htpadmin.html')
        return render(request, 'htp/login.html')


def userlogout(request):
    if (request.is_ajax()):
        if request.session.has_key('admin'):
            del request.session['admin']
            request.session.flush()
        else:
            if request.session.has_key('operator'):
                op_id = request.session['operator']
                Userload.objects.filter(op_id=op_id).delete()
                del request.session['operator']
                if request.session.has_key('camid'):
                    del request.session['camid']
                request.session.flush()
    else:
        if request.session.has_key('admin'):
            del request.session['admin']
            request.session.flush()
        else:
            if request.session.has_key('operator'):
                op_id=request.session['operator']
                Userload.objects.filter(op_id=op_id).delete()
                del request.session['operator']
                if request.session.has_key('camid'):
                    del request.session['camid']
                request.session.flush()
        return render(request, 'htp/login.html')




def generatereport(request):

    return render(request, 'htp/report.html', {'error_message':'Please log in.'})


def admin(request):
    if request.session.has_key('admin'):
        if request.method == "POST":
            user_name = request.POST['username']
            pass_word = request.POST['password']
            select = request.POST['select']

            query = "select * from camera;"
            allCamsObj = Camera.objects.raw(query)

            try:
                obj = Operator.objects.get(op_credentials=user_name)
            except Operator.DoesNotExist:
                obj = None

            if obj is not None:
                return render(request, 'htp/htpadmin.html', {'error_message': 'username already exists', 'allCamsObj': allCamsObj })
            else:
                b = Operator(op_details=select, op_credentials=user_name, op_password=pass_word)
                b.save()
                return render(request, 'htp/htpadmin.html', {'message': 'User Registered', 'allCamsObj': allCamsObj })
        return render(request, 'htp/htpadmin.html', {'allCamsObj',allCamsObj})
    else:
        return render(request, 'htp/login.html', {'error_message': 'Please log in.'})


def registercamera(request):
    if request.session.has_key('admin'):

        if request.method == "POST":
            camerausername = request.POST['camerausername']
            cameraip = request.POST['cameraip']
            cameradetail = request.POST['cameradetail']
            camerapassword = request.POST['camerapassword']

        try:
            obj = Camera.objects.get(details=cameradetail)
        except Camera.DoesNotExist:
            obj = None

        if obj is not None:
            return render(request, 'htp/htpadmin.html', {'error_message': 'camera loaction already exists'})

        else:
            cam = Camera(details=cameradetail, ip_address=cameraip, username=camerausername, password=camerapassword)
            cam.save()

            cam = Camera.objects.get(details=cameradetail, ip_address=cameraip, username=camerausername,
                                     password=camerapassword)

            PROJECT_PATH = os.path.realpath(os.path.dirname(__file__))
            print (PROJECT_PATH)
            path = PROJECT_PATH + '/static/htp/Images/' + str(cam.camera_id)
            print (path)
            if not os.path.exists(path):
                os.makedirs(path)
            return render(request, 'htp/htpadmin.html', {'message': 'Camera Registered'})

        return render(request, 'htp/htpadmin.html')
    else:
        return render(request, 'htp/login.html', {'error_message': 'Please log in.'})


def acceptedAlerts(request):
    if request.session.has_key('operator'):
        if request.method=="POST":
            camid=request.POST['acamVal']
            query='select challans.challan_id,challans.alert_id,challans.description , alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from challans, alerts where camera_id='+camid+' and alerts.alert_id=challans.alert_id'
            alertsobj = Alerts.objects.raw(query)
            context = {
                'alertsobj': alertsobj,
                'camid': camid,
            }
            return render(request, 'htp/accepted_alerts.html', context)

    return render(request, 'htp/login.html', {'error_message':'Please log in.'})


def rejectedAlerts(request):

    if request.session.has_key('operator'):

        if request.method == "POST":
            camid=request.POST['rcamVal']
            query = 'select rejected_alerts.alert_id , alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from rejected_alerts, alerts where camera_id=' + camid + ' and alerts.alert_id=rejected_alerts.alert_id'
            alertsobj = Alerts.objects.raw(query)
            context = {
                'alertsobj': alertsobj,
                'camid': camid,
            }
            return render(request, 'htp/rejected_alerts.html', context)

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})

def detected(request):
    if request.session.has_key('operator'):

        if request.method == "POST":
            camid=request.POST['select_cam']
            if Userload.objects.filter(camera_id=camid):
                if request.session.has_key('camid'):
                    camid = request.session['camid']
                else:
                    camid='0'
                query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
                freeCamsObj = Camera.objects.raw(query)

                query = 'select new_alerts.alert_id, alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where camera_id=' + camid + ' and alerts.alert_id=new_alerts.alert_id'
                alertsobj = Alerts.objects.raw(query)
                op= request.session['operator']
                context = {
                    'alertsobj': alertsobj,
                    'camid': camid,
                    'freeCamsObj': freeCamsObj,
                    'op':op,
                }
                return render(request, 'htp/home.html', context)
            request.session['camid']=camid
            op_id = request.session['operator']
            Userload.objects.filter(op_id=op_id).delete()
            Userload.objects.create(op_id=op_id, camera_id=camid)

        elif request.session.has_key('camid'):
            camid=request.session['camid']
        else:
            query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
            freeCamsObj = Camera.objects.raw(query)
            return render(request, 'htp/home.html', {'freeCamsObj': freeCamsObj})

        query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
        freeCamsObj = Camera.objects.raw(query)

        # display all newAlerts
        query='select new_alerts.alert_id, alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where camera_id='+camid+' and alerts.alert_id=new_alerts.alert_id'
        alertsobj=Alerts.objects.raw(query)

        context={
            'alertsobj':alertsobj,
            'camid':camid,
            'freeCamsObj':freeCamsObj,
        }
        return render(request, 'htp/home.html', context)

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})


def detected1(request):
    if request.session.has_key('operator'):

        if request.method == "POST":
            camid=request.POST['select_start_time']
            query = "select distinct timestamp from alerts;"
            freeCamsObj1 = Alerts.objects.raw(query)

            query = 'select new_alerts.alert_id, alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where timestamp>=' + camid + ' and alerts.alert_id=new_alerts.alert_id';

            alertsobj = Alerts.objects.raw(query)
            op= request.session['operator']
            context = {
                 'alertsobj': alertsobj,
                 'camid': camid,
                 'freeCamsObj': freeCamsObj1,
                 'op':op,
             }
            return render(request, 'htp/home.html', context)
            request.session['camid']=camid
            op_id = request.session['operator']
            Userload.objects.filter(op_id=op_id).delete()
            Userload.objects.create(op_id=op_id, camera_id=camid)

        elif request.session.has_key('camid'):
            camid=request.session['camid']
        else:
            query = "select distinct timestamp from alerts;"
            freeCamsObj1 = Alerts.objects.raw(query)
            return render(request, 'htp/home.html', {'freeCamsObj': freeCamsObj1})

        query = "select distinct timestamp from alerts;"
        freeCamsObj1 = Alerts.objects.raw(query)

        # display all newAlerts
        query = 'select new_alerts.alert_id, alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where timestamp>=' + camid + ' and alerts.alert_id=new_alerts.alert_id';
        alertsobj=Alerts.objects.raw(query)

        context={
            'alertsobj':alertsobj,
            'camid':camid,
            'freeCamsObj':freeCamsObj1,
        }
        return render(request, 'htp/home.html', context)

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})

def detected2(request):
    if request.session.has_key('operator'):

        if request.method == "POST":
            camid=request.POST['select_cam']
            if Userload.objects.filter(camera_id=camid):
                if request.session.has_key('camid'):
                    camid = request.session['camid']
                else:
                    camid='0'
                query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
                freeCamsObj = Camera.objects.raw(query)

                query = 'select new_alerts.alert_id, alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where camera_id=' + camid + ' and alerts.alert_id=new_alerts.alert_id'
                alertsobj = Alerts.objects.raw(query)
                op= request.session['operator']
                context = {
                    'alertsobj': alertsobj,
                    'camid': camid,
                    'freeCamsObj': freeCamsObj,
                    'op':op,
                }
                return render(request, 'htp/home.html', context)
            request.session['camid']=camid
            op_id = request.session['operator']
            Userload.objects.filter(op_id=op_id).delete()
            Userload.objects.create(op_id=op_id, camera_id=camid)

        elif request.session.has_key('camid'):
            camid=request.session['camid']
        else:
            query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
            freeCamsObj = Camera.objects.raw(query)
            return render(request, 'htp/home.html', {'freeCamsObj': freeCamsObj})

        query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
        freeCamsObj = Camera.objects.raw(query)

        # display all newAlerts
        query='select new_alerts.alert_id, alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where camera_id='+camid+' and alerts.alert_id=new_alerts.alert_id'
        alertsobj=Alerts.objects.raw(query)

        context={
            'alertsobj':alertsobj,
            'camid':camid,
            'freeCamsObj':freeCamsObj,
        }
        return render(request, 'htp/home.html', context)

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})
#*******************************************************************************************************

def values(request):
    if request.session.has_key('operator'):

        #query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
        #freeCamsObj = Camera.objects.raw(query)

        if request.method == "POST":
            alertid = request.POST['acceptAlertIdField']
            camid = request.POST['acceptCamField']
            op_id = request.session['operator']
            
            query = 'select a.* from (select alerts.camera_id,challans.alert_id,challans.challan_id,challans.description,alerts.camera_id,challans.alert_id,challans.challan_id,challans.description, alerts.timestamp from challans,alerts where camera_id='+camid+' and    challans.alert_id=alerts.alert_id)a where alert_id ='+ alertid
            alertsobj = Alerts.objects.raw(query)

            context = {
                'alertsobj': alertsobj,
              #  'camid':camid,
              #  'obtainedId': alertid,
              #  'freeCamsObj': freeCamsObj,
            }
            return render(request,'htp/report.html',context)

        #return render(request, 'htp/home.html',{'freeCamsObj': freeCamsObj})

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})


#********************************************************************************************************
def accept(request):
    if request.session.has_key('operator'):

        query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
        freeCamsObj = Camera.objects.raw(query)

        if request.method == "POST":
            alertid = request.POST['acceptIdField']
            camid = request.POST['acceptCamField']
            op_id = request.session['operator']
            license = request.POST['acceptLicenseField']
            

            Challans.objects.create(op_id=op_id, alert_id=alertid, description = license)
          
            NewAlerts.objects.filter(alert_id = alertid).delete()

            query = 'select new_alerts.alert_id , alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where camera_id=' + camid + ' and alerts.alert_id=new_alerts.alert_id;'
            alertsobj = Alerts.objects.raw(query)

            context = {
                'alertsobj': alertsobj,
                'camid':camid,
                'obtainedId': alertid,
                'freeCamsObj': freeCamsObj,
            }
            return render(request, 'htp/home.html',context)

        return render(request, 'htp/home.html',{'freeCamsObj': freeCamsObj})

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})

def reject(request):
    if request.session.has_key('operator'):

        query = "select camera_id from camera where camera_id not in (select camera_id from userload);"
        freeCamsObj = Camera.objects.raw(query)

        if request.method == "POST":

            alertid = request.POST['rejectIdField']
            camid = request.POST['rejectCamField']
            op_id = request.session['operator']

            RejectedAlerts.objects.create(op_id=op_id, alert_id=alertid, description = "N.A.")
            NewAlerts.objects.filter(alert_id = alertid).delete()

            query = 'select new_alerts.alert_id , alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from new_alerts,alerts where camera_id=' + camid + ' and alerts.alert_id=new_alerts.alert_id'
            alertsobj = Alerts.objects.raw(query)

            context = {
                'alertsobj': alertsobj,
                'camid':camid,
                'obtainedId': alertid,
                'freeCamsObj':freeCamsObj,
            }

            return render(request, 'htp/home.html',context)
        return render(request, 'htp/home.html',{'freeCamsObj':freeCamsObj})

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})


def revokeChallan(request):
    if request.session.has_key('operator'):

        if request.method == "POST":

            camid=request.POST['camField']
            alertid = request.POST['idField']

            NewAlerts.objects.create(alert_id = alertid)
            Challans.objects.filter(alert_id = alertid).delete()

            query = 'select challans.alert_id , alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from challans, alerts where camera_id='+camid+' and alerts.alert_id=challans.alert_id;'
            alertsobj = Alerts.objects.raw(query)

            context = {
                'alertsobj': alertsobj,
                'camid':camid,
                'obtainedId': alertid,
            }

            return render(request, 'htp/accepted_alerts.html',context)
        return render(request, 'htp/accepted_alerts.html')

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})


def revokeRejected(request):
    if request.session.has_key('operator'):

        if request.method == "POST":

            camid=request.POST['camField']
            alertid = request.POST['idField']

            NewAlerts.objects.create(alert_id = alertid)
            RejectedAlerts.objects.filter(alert_id = alertid).delete()

            query = 'select rejected_alerts.alert_id , alerts.timestamp, alerts.horizontal, alerts.vertical, alerts.width, alerts.height from rejected_alerts,alerts where camera_id=' + camid + ' and alerts.alert_id=rejected_alerts.alert_id'
            alertsobj = Alerts.objects.raw(query)

            context = {
                'alertsobj': alertsobj,
                'camid':camid,
                'obtainedId': alertid,
            }

            return render(request, 'htp/rejected_alerts.html',context)
        return render(request, 'htp/rejected_alerts.html')

    return render(request, 'htp/login.html', {'error_message': 'Please log in.'})
