from django.apps import AppConfig


class HtpConfig(AppConfig):
    name = 'htp'
