from django.conf.urls import url
from . import views

app_name = 'htp'

urlpatterns=[
    url(r'^$', views.home, name='home'),

    url(r'^accept/$', views.accept, name='accept'),
    url(r'^reject/$', views.reject, name='reject'),

    url(r'^accepted_alerts/revoke/$', views.revokeChallan, name='revokeChallan'),
    url(r'^rejected_alerts/revoke/$', views.revokeRejected, name='revokeRejected'),

    url(r'^userlogin/$', views.userlogin, name='tvdsuserlogin'),
    url(r'^userlogout/$', views.userlogout, name='userlogout'),
    url(r'^generatereport/$', views.generatereport, name='generatereport'),

    url(r'^home/$', views.home, name ='home'),

    url(r'^htpadmin/$', views.admin, name='htpadmin'),
    url(r'^registercamera/$', views.registercamera, name='registercamera'),

    url(r'^accepted_alerts/$', views.acceptedAlerts, name='accepted_alerts'),
    url(r'^rejected_alerts/$', views.rejectedAlerts, name='rejected_alerts'),
    url(r'^home/detected/$', views.detected, name='detected'),
    url(r'^home/detected1/$', views.detected1, name='detected1'),
    url(r'^home/detected2/$', views.detected, name='detected2'),
]
