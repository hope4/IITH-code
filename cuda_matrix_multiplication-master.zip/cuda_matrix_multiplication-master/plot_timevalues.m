clc
close all
clear all

data = load('timevalues_millisec.txt');



k = 0;
i = 1;
while(i<90)
       for j = 1:9
	  x(k) = j;
	  y(k) = data(1,i);
          i = i + j;
          k = k +1;
	end
        k = 1;
        figure
	plot(x,y);
end
